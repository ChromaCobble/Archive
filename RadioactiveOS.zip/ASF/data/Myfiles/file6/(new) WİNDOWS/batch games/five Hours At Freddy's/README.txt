Version: 1.0

*Have fun!

1) If stuck check the walkthrough

2) If the game exits suddenly, you typed or entered something wrong!

3) Use the SPACEBAR [---------] to move through sequences and
[ENTER ->] for giving answers

4)It is advised to put the game in a separate folder because it has many files